#################
Django Highcharts
#################
This is a Fork of novapost package to
generate charts in your Django application using Highcharts helpers.

- Pie with drilldown charts
- 3D Pie Options
- Speedometer charts
- Multiple Axes charts
- Area charts
- Bar charts
- Heatmap charts
- Polar Spider web charts
- HighStock basic charts

* `Source code is on Github <https://github.com/ernestoarbitrio/django-highcharts>`_
